import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";

export default function DailyRoutineApp() {
  const [tasks, setTasks] = useState([
    { time: "04:00 - 04:30", title: "Despertar & Gratitud", done: false },
    { time: "04:30 - 05:00", title: "Meditación & Visualización", done: false },
    { time: "05:00 - 05:30", title: "Ejercicio", done: false },
    { time: "05:30 - 06:30", title: "Lectura & Estudio", done: false },
    { time: "06:30 - 07:00", title: "Desayuno & Planificación", done: false },
    { time: "07:00 - 12:00", title: "Trabajo Profundo", done: false },
    { time: "12:00 - 13:00", title: "Almuerzo & Descanso activo", done: false },
    { time: "13:00 - 15:00", title: "Trabajo Estratégico", done: false },
    { time: "15:00 - 16:00", title: "Reunión Mastermind", done: false },
    { time: "16:00 - 17:00", title: "Servicio / Creatividad", done: false },
    { time: "17:00 - 18:00", title: "Tiempo Libre / Familia", done: false },
    { time: "18:00 - 19:00", title: "Cena + Revisión", done: false },
    { time: "19:00 - 20:00", title: "Estudio Ligero / Inspiración", done: false },
    { time: "20:00 - 21:00", title: "Preparación para dormir", done: false }
  ]);

  const toggleTask = (index) => {
    const updated = [...tasks];
    updated[index].done = !updated[index].done;
    setTasks(updated);
  };

  const progress = Math.round((tasks.filter(t => t.done).length / tasks.length) * 100);

  return (
    <div className="p-6 max-w-3xl mx-auto space-y-4">
      <h1 className="text-2xl font-bold text-center">Rutina Diaria – Piense y Hágase Rico</h1>
      <Progress value={progress} />
      {tasks.map((task, index) => (
        <Card key={index} className={task.done ? "bg-green-100" : ""}>
          <CardContent className="flex justify-between items-center p-4">
            <div>
              <p className="text-sm text-gray-500">{task.time}</p>
              <h2 className="text-lg font-semibold">{task.title}</h2>
            </div>
            <Button onClick={() => toggleTask(index)} variant={task.done ? "secondary" : "default"}>
              {task.done ? "Completado" : "Marcar"}
            </Button>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}